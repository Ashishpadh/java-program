package org.jsp.webapp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsp.webapp.dao.Userdao;
import org.jsp.webapp.dto.User;



@WebServlet("/reg")

public class Resister {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("nm");
		long phone = Long.parseLong(req.getParameter("ph"));
		String email = req.getParameter("em");
		String password = req.getParameter("ps");
		User user = new User();
		user.setPassword(password);
		user.setEmail(email);
		user.setPhone(phone);
		user.setName(name);
		Userdao dao = new Userdao();
		user = dao.saveUser(user);
		PrintWriter writer=resp.getWriter();
		System.out.println("user saved with ID:" + user.getId());
		writer.write("<html><body><h1>you are register with id:"+user.getId()+"</h1></body></html>");
	}

}
