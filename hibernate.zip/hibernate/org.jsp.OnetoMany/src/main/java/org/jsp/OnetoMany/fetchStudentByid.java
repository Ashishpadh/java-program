package org.jsp.OnetoMany;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class fetchStudentByid {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the batch id to student details");
		int id=sc.nextInt();
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager em=f.createEntityManager();
		
		Batch b=em.find(Batch.class, id);
		if(b!=null) {
			List<student> students=b.getStudent();
			for(student st:students) {
				System.out.println("id : "+st.getId());
				System.out.println("name : "+st.getName());
				System.out.println("degree : "+st.getDegree());
				System.out.println("percentage : "+st.getPerc());
				System.out.println(".....................................");
			}
			
		}
		else
		{
			System.err.println("invlid batch id");
		}
		
		
	}

}
