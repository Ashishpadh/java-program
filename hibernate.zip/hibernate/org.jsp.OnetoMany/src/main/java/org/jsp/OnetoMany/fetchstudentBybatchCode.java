package org.jsp.OnetoMany;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class fetchstudentBybatchCode {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the batch batch code to display student details");
		String batchcode=sc.next();
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager em=f.createEntityManager();
		Query q=em.createQuery("select b from Batch b where b.batchcode=?1");
		q.setParameter(1, batchcode);
		
		try {
		Batch b=(Batch) q.getSingleResult();
			List<student> students=b.getStudent();
			for(student st:students) {
				System.out.println("id : "+st.getId());
				System.out.println("name : "+st.getName());
				System.out.println("degree : "+st.getDegree());
				System.out.println("percentage : "+st.getPerc());
				System.out.println(".....................................");
			}
			
		} catch(NoResultException e){
			System.err.println("invlid batch id");
		}
	}
	}
	