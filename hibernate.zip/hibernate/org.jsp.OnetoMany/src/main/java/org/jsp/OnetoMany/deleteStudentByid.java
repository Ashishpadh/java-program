package org.jsp.OnetoMany;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class deleteStudentByid {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the batch batch code to display student details");
		String batch=sc.next();
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		Query q=em.createQuery("select b from Batch b where b.subject=?1");
		q.setParameter(1, batch);
		Batch p=em.find(Batch.class, 2);
		if(p!=null) {
		em.remove(p);
		tra.begin();
		tra.commit();
		}
		
	}

}
