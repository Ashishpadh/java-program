package org.jsp.OnetoMany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class deleteStudentBybatchcode {
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		Batch p=em.find(Batch.class, 1);
		if(p!=null) {
			em.remove(p);
			System.out.println("person data delete sussfully");
			
		}
		else {
			System.out.println("invalid id");
		}
		tra.begin();
		tra.commit();
		
	}

	}
	

