package org.jsp.OnetoMany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class SavebatchStudent {
	public static void main(String[] args) {
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		
		EntityManager em=f.createEntityManager();
		EntityTransaction t=em.getTransaction();
		Batch b=new Batch();
		b.setSubject("core java");
		b.setStartDate(LocalDate.parse("2022-08-25"));
		b.setBatchcode("as2354");
		
		student s=new student();
		s.setName("padhi");
		s.setDegree("B.E");
		s.setPerc(23);
		
		student s2=new student();
		s2.setName("ashish");
		s2.setDegree("mca");
		s2.setPerc(89);
		
		student s3=new student();
		s3.setName("debahis");
		s3.setDegree("bsc");
		s3.setPerc(90);
		
		b.setStudent(new ArrayList<student>(Arrays.asList(s,s2,s3)));
		
		em.persist(b);
		t.begin();
		t.commit();
	}

}
