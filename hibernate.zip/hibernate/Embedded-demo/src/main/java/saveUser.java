import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class saveUser {
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transation=manager.getTransaction();
		Users user=new Users();
		user.setAge(23);
		user.setName("ashish padhi");
		
		UserId id=new UserId();
		id.setEmail("ashish@gmail.com");
		id.setPhone(2311415);
		user.setId(id);
		
		manager.persist(user);
		transation.begin();
		transation.commit();
	}

}
