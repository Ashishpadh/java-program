package org.jsp.onetomany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UpdateUser {
	public static void main(String[] args) {
        EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager em=f.createEntityManager();
		EntityTransaction t=em.getTransaction();
		
		User u=new User();
		u.setId(1);
		u.setName("ashish padhi");
		u.setDob(LocalDate.parse("1999-04-04"));
		u.setMail("ashish@gmail.com");
		u.setPassword("sd234");
		
		post p=new post();
		p.setId(1);
		p.setCaption("aefds");
		p.setLocation("india");
		p.setUser(u);
		
		
		post p1=new post();
		p1.setCaption("aefds");
		p1.setLocation("india");
		p1.setUser(u);
		
		u.setPost(new ArrayList<post>(Arrays.asList(p,p1)));
		em.merge(u);
		t.begin();
		t.commit();
	}

}
