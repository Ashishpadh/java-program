package org.jsp.onetomany;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;



public class featchUser {
	public static void main(String[] args) {
		Scanner Sc =new Scanner(System.in);
		System.out.println("enter the user id to display");
		int id=Sc.nextInt();
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		User u=em.find(User.class, id);
		if(u!=null)
		{
			System.out.println("name : "+u.getName());
			System.out.println("gender : "+u.getDob());
			System.out.println("phone : "+u.getPassword());
		}
		else {
			System.out.println("invalid user id");
		}
		
		System.out.println("display the pancard");
		post p=em.find(post.class, id);
		if(p!=null) {
			System.out.println("number : "+p.getCaption());
			System.out.println("pincode : "+p.getLocation());
		}
		else {
			System.out.println("invalid post id");
		}
		
		
	}
		
	}


