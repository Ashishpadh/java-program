package org.jsp.foodorder;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.jsp.foodorder.dao.SaveFoodorderdao;
import org.jsp.foodorder.dao.SaveFoodorderdao.UpdateFoodorderdao;



public class SaveOrder {
	public static void main(String[] args) {
		foodorder order=new foodorder();
		order.setDistance(100.0);
		order.setPrice(500.0);
//		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
//		EntityManager manager=factory.createEntityManager();
//		EntityTransaction transaction=manager.getTransaction();
//	    transaction.begin();
//	    manager.persist(order);
//	    transaction.commit();
//	    System.out.println(order.getPrice());
//	    System.out.println(order.getId());
	    SaveFoodorderdao dao=new SaveFoodorderdao();
	    order=dao.SaveFoodorder(order);
	    System.out.println("order with  id :"+order.getId());
	    System.out.println("order with id :"+order.getPrice());
	    
//	    SaveFoodorderdao dao=new SaveFoodorderdao();
	    
//	    UpdateFoodorderdao updao=new UpdateFoodorderdao();
	}

	

}
