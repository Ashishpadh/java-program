package org.jsp.foodorder.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.jsp.foodorder.foodorder;



public class SaveFoodorderdao {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
	EntityManager manager=factory.createEntityManager();
	public foodorder SaveFoodorder(foodorder order) {
		EntityTransaction transaction=manager.getTransaction();
		manager.persist(order);
		transaction.begin();
		transaction.commit();
		return order;
	}
	
	public class UpdateFoodorderdao {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		public foodorder SaveFoodorder(foodorder order) {
			
			manager.persist(order);
			transaction.begin();
			transaction.commit();
			return order;
		}
	}
	
	public foodorder getFoodorderById(int id) {
		return manager.find(foodorder.class, id);
	}
	public boolean deleteFooderOrder(int id) {
	  foodorder order=getFoodorderById(id);
	  if(order!=null) {
		  manager.remove(order);
		  return true;
	  }
	  return false;
	}
	public List<foodorder> FindAllOrder(){
		String hql="Select f from foodorder f";
		Query q=manager.createQuery(hql);
		return q.getResultList();
	}
	
}
