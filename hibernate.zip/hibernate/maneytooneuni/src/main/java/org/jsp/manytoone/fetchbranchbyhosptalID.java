package org.jsp.manytoone;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;



public class fetchbranchbyhosptalID {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the hosptal id to display branch");
		int id=sc.nextInt();
        EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager em=f.createEntityManager();
		EntityTransaction t=em.getTransaction();
		
		
		Query q=em.createQuery("select b from branch b where b.hospital.id=?1");
		q.setParameter(1, q);
		List<branch> branchs=q.getResultList();
		for(branch b:branchs) {
			System.out.println("branch id: "+b.getId());
			System.out.println("branch name :"+b.getName());
			System.out.println("branch phone :"+b.getPhone());
			
			System.out.println("..............................");
		}
		
	}

}
