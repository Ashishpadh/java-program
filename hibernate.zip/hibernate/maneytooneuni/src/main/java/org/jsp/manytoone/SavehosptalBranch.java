package org.jsp.manytoone;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class SavehosptalBranch {
	public static void main(String[] args) {
		hospital h=new hospital();
		h.setName("apollo");
		h.setYoeb(LocalDate.parse("1999-02-02"));
		
		
		branch b=new branch();
		b.setHosptals(h);
		b.setName("apollo balasore");
		b.setPhone(123456);
		
		
		branch b1=new branch();
		b1.setHosptals(h);
		b1.setName("apollo balasore");
		b1.setPhone(123456);
		
		
		
		branch b2=new branch();
		b2.setHosptals(h);
		b2.setName("apollo balasore");
		b2.setPhone(123456);
		
        EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager em=f.createEntityManager();
		EntityTransaction t=em.getTransaction();
		
		em.persist(b);
		em.persist(b1);
		em.persist(b2);
		t.begin();
		t.commit();
		
	}

}
