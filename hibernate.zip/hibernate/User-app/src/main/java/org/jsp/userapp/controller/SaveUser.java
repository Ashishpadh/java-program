package org.jsp.userapp.controller;


import org.jsp.userapp.dao.Userdao;
import org.jsp.userapp.dto.User;

public class SaveUser {
	public static void main(String[] args) {
		User u=new User();
		u.setName("padhisdf");
		u.setAge(23);
		u.setPassword("ashish1223");
		u.setPhone(123456);
		System.out.println("id befor saving :"+u.getId());
		Userdao dao=new Userdao();
		u=dao.saveUser(u);
		System.out.println("user sav ed with id:"+u.getId());
//		u=dao.updateUser(u);
//		System.out.println("user update with name:"+u.getId());
	}
}
