package org.jsp.userapp.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.jsp.userapp.dto.User;

public class Userdao {
	Session s=new Configuration().configure().buildSessionFactory().openSession();
	public User saveUser(User user) {
		s.save(user);
		Transaction t=s.beginTransaction();
		t.commit();
		return user;
	}
	public User updateUser(User user) {
		s.update(user);
		
		Transaction t=s.beginTransaction();
		t.commit();
		return user;
	}
	boolean deleteUser(int user_id) {
		User u=s.find(User.class, user_id);
		if(u!=null) {
			s.delete(u);
			return true;
		}
		return false;
	}
	User findUser(int user_id) {
		return s.find(User.class, user_id);
	}
	List<User> findAlluser(){
		Query<User> q=s.createQuery("select u from User u");
		return q.getResultList();
	}
	
}
















