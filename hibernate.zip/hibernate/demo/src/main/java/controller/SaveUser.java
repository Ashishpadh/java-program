package controller;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import javax.persistence.Persistence;

import dto.User;

public class SaveUser {
public static void main(String[] args) {
	User u=new User();
	u.setAge(24);
	u.setName("ashish");
	EntityManagerFactory fact=Persistence.createEntityManagerFactory("dev");
	EntityManager em=fact.createEntityManager();
	EntityTransaction tra=em.getTransaction();
	em.persist(u);
	tra.begin();
	tra.commit();
	System.out.println("user save id"+u.getId());
}	

}
