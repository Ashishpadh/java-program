package controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import dto.User;

public class Update {
	public static void main(String[] args) {
		User u=new User();
		u.setId(1);
		u.setName("padhi");
		u.setAge(23);
		EntityManagerFactory fa=Persistence.createEntityManagerFactory("dev");
		EntityManager em=fa.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		em.merge(u);
		tra.begin();
		tra.begin();
		System.out.println("user saved id"+u.getId());
	}

}
