package org.jsp.manytomany;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class fetchstudentdot {
	public static void main(String[] args) {
		
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Student Name");
	String Student_name=sc.next();
	
	EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
	EntityManager m=f.createEntityManager();
	Query  q=m.createQuery("select s from student s where name=?2");
		q.setParameter(2, Student_name);
	try
	{
		student c=(student) q.getSingleResult();
		List<course> students =c.getCourse();
		for(course l:students)
		{
		System.out.println("ID "+l.getId());
		System.out.println("Subject name " +l.getSubject());
		System.out.println("Duration "+l.getDuration());
		System.out.println("-------------------------------");
		}
	}
	catch(NoResultException e)
	{
		System.out.println("Invalid student name");
	}
}
	
}
		
	
	
