package org.jsp.manytomany;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class test {
	public static void main(String[] args) {
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		System.out.println(f);
	}

}
