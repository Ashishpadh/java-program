package org.jsp.manytomany;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class fetchstudentid {
	public static void main(String[] args) {
	Scanner Sc =new Scanner(System.in);
	System.out.println("enter the user id to display");
	int id=Sc.nextInt();
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
	EntityManager em=factory.createEntityManager();
	EntityTransaction tra=em.getTransaction();
	student u=em.find(student.class, id);
	if(u!=null)
	{
		System.out.println("name : "+u.getName());
		System.out.println("gender : "+u.getPhone());
		System.out.println("phone : "+u.getPerc());
	}
	else {
		System.out.println("invalid student  id");
	}
	System.out.println("display the course");
    course p=em.find(course.class, id);
	if(p!=null) {
		System.out.println("number : "+p.getSubject());
		System.out.println("pincode : "+p.getDuration());
	}
	else {
		System.out.println("invalid course id");
	}
	
}
}
