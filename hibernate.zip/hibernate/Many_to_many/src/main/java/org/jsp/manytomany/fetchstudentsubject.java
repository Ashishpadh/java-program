package org.jsp.manytomany;

import java.util.List;
import java.util.Scanner;

public class fetchstudentsubject {
	
		Scanner sc=new Scanner(System.in);
		String subject=sc.next();
		fetchstudentdot dao=new fetchstudentdot();
		List<student> students=dao.fetchstudentsubject(subject);
		if(students!=null) {
			for(student st:students) {
				System.out.println("id"+st.getId());
				System.out.println("name"+st.getName());
				System.out.println("phone number"+st.getPhone());
				System.out.println("percentage "+st.getPerc());
				System.out.println(".......................");
			}
		}
		else {
			System.out.println("invalid subject name");
		}
		return null;
		
	}

}
