package main.org;


public class Hibernatedemo {
	public static void main(String[] args) {
		
	}
}
