package org.jsp.onetooneby;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class FeatchUser {
	public static void main(String[] args) {
		Scanner Sc =new Scanner(System.in);
		System.out.println("enter the user id to display");
		int id=Sc.nextInt();
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		Person p=em.find(Person.class, id);
		if(p!=null)
		{
			System.out.println("name : "+p.getName());
			System.out.println("gender : "+p.getGender());
			System.out.println("phone : "+p.getPhone());
		}
		else {
			System.out.println("invalid data");
		}
		
		System.out.println("display the pancard");
		pancard c=em.find(pancard.class, id);
		if(c!=null) {
			System.out.println("number : "+c.getNumber());
			System.out.println("pincode : "+c.getPincode());
		}
		else {
			System.out.println("invalid data entry");
		}
		
		
	}

}
