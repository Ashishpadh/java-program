package org.jsp.onetooneby;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class saveperson {
	public static void main(String[] args) {
		
	EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
	
	EntityManager em=f.createEntityManager();
	EntityTransaction t=em.getTransaction();
	
	Person p=new Person();
	p.setName("sdfgh");
	p.setGender("mail");
	p.setPhone(345678);
	
	pancard c=new pancard();
	c.setPincode(2334);
	c.setNumber("asda242h");
	
	p.setCard(c);
	c.setP(p);
	
	em.persist(p);
	t.begin();
	t.commit();
	
	

	}
}
