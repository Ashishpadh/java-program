package org.jsp.onetooneby;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.engine.jdbc.batch.spi.Batch;

public class fetch {
	public static void main(String[] args) {
		EntityManagerFactory fa=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=fa.createEntityManager();
		Batch b=manager.find(Batch.class, 3);
		
	}

}
