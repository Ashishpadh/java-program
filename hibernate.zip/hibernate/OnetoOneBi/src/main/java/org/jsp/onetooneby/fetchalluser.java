package org.jsp.onetooneby;

public class fetchalluser {

}
