package org.jsp.onetooneby;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class UpdateUser {
	
public static void main(String[] args) {
EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
	
	EntityManager em=f.createEntityManager();
	EntityTransaction t=em.getTransaction();
	
	Person p=new Person();
	p.setId(1);
	p.setName("Ashish");
	p.setGender("mail");
	p.setPhone(345678);
	
	pancard c=new pancard();
	c.setId(1);
	c.setPincode(2334);
	c.setNumber("Ashsh242h");
	
	p.setCard(c);
	c.setP(p);
	
	em.merge(p);
	t.begin();
	t.commit();
	
		
		

}
}
