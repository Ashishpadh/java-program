package hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeleteUser {
	public static void main(String[] args) {
		Configuration cfg=new Configuration().configure();
		SessionFactory factory=cfg.buildSessionFactory();
		Session s=factory.openSession();
		Transaction t=s.beginTransaction();
		User u=s.find(User.class, 3);
		if(u!=null) {
			s.delete(u);
			System.out.println("user delete succesfully");
		}
		else {
			System.err.println("invalid id");
		}
		t.commit();
	}
}