package hibernate;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class fetchName {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the name to display the details");
	String name=sc.next();
		
		Configuration cfg=new Configuration().configure();
		SessionFactory factory=cfg.buildSessionFactory();
		Session s=factory.openSession();
		Query<User> q=s.createQuery("select u from User u where u.name=? 1 ");
		q.setParameter(1, name);
		List<User> users=q.getResultList();
		for(User u:users) {
			System.out.println("id:"+u.getId());
			System.out.println("name:"+u.getName());
			System.out.println("phone number:"+u.getPhone());
			System.out.println("age:"+u.getAge());
			System.out.println("--------------------------");
		}
	}

}
