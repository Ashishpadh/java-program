package hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SaveorUpdate {
	public static void main(String[] args) {
		User u=new User();
		u.setId(6);
		u.setName("banty");
		u.setAge(24);
		u.setPhone(797835796834L);
		Configuration cfg=new Configuration().configure();
		SessionFactory factory=cfg.buildSessionFactory();
		Session s=factory.openSession();
		s.saveOrUpdate(u);
		Transaction t=s.beginTransaction();
		t.commit();
		System.err.println("update data");
	}
		

}
