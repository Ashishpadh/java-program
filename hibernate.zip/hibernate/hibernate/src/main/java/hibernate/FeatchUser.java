package hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FeatchUser {
	public static void main(String[] args) {
		Configuration cfg=new Configuration().configure();
		SessionFactory factory=cfg.buildSessionFactory();
		Session s=factory.openSession();
		User u=s.find(User.class, 2);
		if(u!=null) {
		System.out.println("Name: "+u.getName()+ "Age: "+ u.getAge()+ "id: "+ u.getId());
		}
		else
		{
			System.err.println("invalid data");
		}
	}

}
