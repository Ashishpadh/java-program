package onetomaney;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class savepoint {
	public static void main(String[] args) {
		department d=new department();
		d.setName("trainers");
		d.setLocation("btm");
		
		
		employee e=new employee();
		e.setName("ashish");
		e.setDesg("xyz");
		e.setSalary(234567);
		
		employee e1=new employee();
		e1.setName("ashish padhi");
		e1.setDesg("xyzdfdasf");
		e1.setSalary(234567);
		
		d.setEmps(new ArrayList<employee>(Arrays.asList(e,e1)));
	}

}
