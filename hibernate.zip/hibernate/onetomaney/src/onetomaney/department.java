package onetomaney;

import java.util.List;

public class department {
	private String name;
	private String location;
	
	private  List<employee> emps;
	public List<employee> getEmps() {
		return emps;
	}
	public void setEmps(List<employee> emps) {
		this.emps = emps;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

}
