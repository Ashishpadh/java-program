/**
 * 
 */
/**
 * @author Admin
 *
 */
module onetomaney {
}