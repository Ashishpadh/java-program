package ManyToMany.controller;

import java.util.Scanner;

import ManeyToManeyDao.StudentDao;

public class main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
//		int course_id=sc.nextInt();
		StudentDao dao=new StudentDao();
		System.out.println("enter trhe student id");
		
		
	}

}
