package ManeyToManeyDao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import ManyToManys.Student;
import ManyToManys.course;

public class StudentDao {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
	EntityManager em=factory.createEntityManager();
	EntityTransaction tra=em.getTransaction();
	public List<Student> fetchStudentBycourseId(int course_id){
	    course c=em.find(course.class, course_id);
	    if(c!=null) {
	    	return c.getStudents();
	    	
	    }
	    return null;
	}
	public List<Student> fetchStudentBysubject(String subject){
		Query q=em.createNamedQuery("select c from course c where c.subject=?1");
		q.setParameter(1, subject);
		List<course>courses=q.getResultList();
		if(courses.size()>0) {
			course c=courses.get(0);
			return c.getStudents();
		}
		return null;
	}
	

}
