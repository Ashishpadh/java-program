package ManyToManys;

import java.util.ArrayList;
import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Saveacessall {
	public static void main(String[] args) {
        EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager em=f.createEntityManager();
		EntityTransaction t=em.getTransaction();
		
		Student s=new Student();
		s.setName("ashish padhi");
		s.setPhone(45678);
		s.setPerc(67);
		
		Student s1=new Student();
		s1.setName("debashis padhi");
		s1.setPhone(45678);
		s1.setPerc(67);
		
		course c=new course();
		c.setDuration(23);
		c.setSubject("java");
		course c1=new course();
		c1.setDuration(21);
		c1.setSubject("j2ee");
		
		s.setCourse(new ArrayList<course>(Arrays.asList(c,c1)));
		s1.setCourse(new ArrayList<course>(Arrays.asList(c)));
		c.setStudents(new ArrayList<Student>(Arrays.asList(s,s1)));
		c1.setStudents(new ArrayList<Student>(Arrays.asList(s)));
		em.merge(s);
		em.merge(s1);
		t.begin();
		t.commit();
		
	}

}
