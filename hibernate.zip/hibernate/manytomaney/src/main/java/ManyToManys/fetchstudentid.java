package ManyToManys;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class fetchstudentid {
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your course id");
		int id=sc.nextInt();
		
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager m=f.createEntityManager();
		course c=m.find(course.class, id);
		if(c!=null)
		{
			List<Student> students =c.getStudents();
			for(Student l:students)
			{
			System.out.println("ID :"+c.getId());
			System.out.println("Student Name :"+l.getName());
			System.out.println("Phone number :"+l.getPhone());
			System.out.println("Student percentage "+l.getPerc());
			System.out.println("-------------------------------");
			}
		}
		else
		{
			System.err.print("Invalid id ");
		}
	}

}
