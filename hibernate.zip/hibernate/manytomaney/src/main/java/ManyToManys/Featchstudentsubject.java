package ManyToManys;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;



public class Featchstudentsubject {
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Course Subject name");
		String subject=sc.next();
		
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager m=f.createEntityManager();
		Query  q=m.createQuery("select s from Course s where subject=?1");
			q.setParameter(1, subject);
		try
		{
			course c=(course) q.getSingleResult();
			List<Student> students =c.getStudents();
			for(Student l:students)
			{
			System.out.println("ID "+l.getId());
			System.out.println("Student Name "+l.getName());
			System.out.println("Phone number "+l.getPhone());
			System.out.println("Student percentage "+l.getPerc());
			System.out.println("-------------------------------");
			}
		}
		catch(NoResultException e)
		{
			System.out.println("Invalid subject name");
		}
		
	}

}
