package ManyToManys;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class fetchstudentname {
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student Name");
		String Student_name=sc.next();
		
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		EntityManager m=f.createEntityManager();
		Query  q=m.createQuery("select s from Student s where name=?1");
			q.setParameter(1, Student_name);
		try
		{
			Student c=(Student) q.getSingleResult();
			List<course> students =c.getCourse();
			for(course l:students)
			{
			System.out.println("ID "+l.getId());
			System.out.println("Subject name " +l.getSubject());
			System.out.println("Duration "+l.getDuration());
			System.out.println("-------------------------------");
			}
		}
		catch(NoResultException e)
		{
			System.out.println("Invalid student name");
		}
	}

}
