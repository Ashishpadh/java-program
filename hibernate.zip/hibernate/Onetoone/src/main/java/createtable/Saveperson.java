package createtable;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Saveperson {
	public static void main(String[] args) {
		
		person p=new person();
		p.setName("ashish");
		p.setPhone(1234567);
		
		pancard c=new pancard();
		
		c.setDob(LocalDate.parse("1999-07-01"));
		c.setNumber("asda324g");
		c.setPincode(23456);
	    
		p.setCard(c);
		
		EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
		
		EntityManager em=f.createEntityManager();
		EntityTransaction t=em.getTransaction();
		
		em.merge(p);
		t.begin();
		t.commit();
		
		
		
   }

}
