package table;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class SaveTable {
	public static void main(String[] args) {
		insert u=new insert();
		u.setId(1);
		u.setName("babuchhua");
		u.setAge(28);
		u.setPhone(2345678);
		u.setEmail("ashishpadhi0202@gmail.com");
		u.setPassword("123456789");
		Configuration cfg=new Configuration().configure();
		SessionFactory factory=cfg.buildSessionFactory();
		Session s=factory.openSession();
		s.save(u);
		Transaction t=s.beginTransaction();
		t.commit();
		System.out.println("save data");
		
	}

}
