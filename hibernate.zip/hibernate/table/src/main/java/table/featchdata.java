package table;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class featchdata {
	public static void main(String[] args) {
		Configuration cfg=new Configuration().configure();
		SessionFactory fact=cfg.buildSessionFactory();
		Session s=fact.openSession();
		Transaction t=s.beginTransaction();
		insert i=s.find(insert.class, 3);
		if(i!=null)
		{
			System.out.println("id"+i.getId());
			System.out.println("name"+i.getName());
			System.out.println("email"+i.getEmail());
			System.out.println("phine"+i.getPhone());
			System.out.println("password"+i.getPassword());
		}
		else
		{
			System.out.println("invalid entrey");
		}
	}

}
