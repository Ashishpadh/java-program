package table;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Deletetable {
	public static void main(String[] args) {
		Configuration cfg=new Configuration().configure();
		SessionFactory fact=cfg.buildSessionFactory();
		Session s=fact.openSession();
		Transaction t=s.beginTransaction();
		insert i=s.find(insert.class, 1);
		if(i!=null)
		{
			s.delete(i);
			System.out.println("user delete succfully");
		}
		else {
			System.out.println("invalid user");
		}
		t.commit();
	}

}
