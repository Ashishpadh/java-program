package table;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateTable {
	public static void main(String[] args) {
		insert i=new insert();
		i.setId(4);
		i.setName("Ashish padhi");
		i.setAge(23);
		i.setEmail("ashishpadhi532@gmail.com");
		i.setPassword("as234567");
		i.setPhone(234567);
		Configuration cfg=new Configuration().configure();
		SessionFactory fa=cfg.buildSessionFactory();
		Session s=fa.openSession();
		Transaction t=s.beginTransaction();
		s.update(i);
		t.commit();
				
	}

}
