package table;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SaveorUpadate {
	public static void main(String[] args) {
		insert i=new insert();
		i.setId(3);
		i.setName("ashish padhi");
		i.setAge(24);
		i.setPhone(2345678);
		i.setEmail("ashish@gmail.com");
		i.setPassword("234567");
		Configuration cfg=new Configuration().configure();
		SessionFactory fact=cfg.buildSessionFactory();
		Session s=s=fact.openSession();
		Transaction t=s.beginTransaction();
		s.saveOrUpdate(i);
		t.commit();
		System.out.println("update succfully");
		
	}

}
