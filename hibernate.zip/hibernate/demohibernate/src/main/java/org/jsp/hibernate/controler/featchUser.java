package org.jsp.hibernate.controler;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.jsp.hibernate.dto.User;

public class featchUser {
	public static void main(String[] args) {
		Scanner Sc =new Scanner(System.in);
		System.out.println("enter the user id to display");
		int id=Sc.nextInt();
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		
		User u=em.find(User.class, id);
		if(u!=null)
		{
			System.out.println("name : "+u.getName());
			System.out.println("age : "+u.getAge());
		}
		else 
		{
			System.out.println("invalid data");
		}
	}

}