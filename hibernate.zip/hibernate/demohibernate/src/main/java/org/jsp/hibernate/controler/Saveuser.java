package org.jsp.hibernate.controler;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.jsp.hibernate.dto.User;

public class Saveuser {
	public static void main(String[] args) {
		User u=new User();
		u.setName("Ashish ");
		u.setPhone(233434569);
		u.setPassword("asdhf@123");
		u.setAge(46);
		u.setEmail("ish123@gmail.com");
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		
		em.persist(u);
		tra.begin();
		tra.commit();
		System.out.println("user save id"+ u.getId());
	}

}

