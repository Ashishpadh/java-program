package org.jsp.hibernate.controler;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.jsp.hibernate.dto.User;

public class UpdateUsre {
	public static void main(String[] args) {
		
		User u=new User();
		u.setId(1);
		u.setName("padhi");
		u.setPhone(3454);
		u.setPassword("Ashish@12345");
		u.setAge(23);
		u.setEmail("ashishpadhi@gmail.com");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		
		
		em.merge(u);
		tra.begin();
		tra.commit();
		System.out.println("user update id"+u.getId());
	}

}
