package org.jsp.hibernate.control;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.jsp.hibernate.dto.User;



public class deleteUser {
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		User u=em.find(User.class, 2);
		if(u!=null) {
			em.remove(u);
			System.out.println("user delete succesfully");
		}
		else {
			System.err.println("invalid id");
		}
		tra.begin();
		tra.commit();
	}

}
