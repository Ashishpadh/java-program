package org.jsp.hibernate.control;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.jsp.hibernate.dto.User;

public class fetchallUser {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the user id print the detels");
		String name=sc.next();
		
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
	EntityManager em=factory.createEntityManager();
	
	String hql="select u from User u where u.name=?1"; 
	Query q=em.createQuery(hql);
	q.setParameter(1, name);
	List<User> users=q.getResultList();
	for(User u:users)
		
	{
		System.out.println("id :"+u.getId());
		System.out.println("name :"+u.getName());
		System.out.println("age :"+u.getAge());
		
		
	}
	}

}
