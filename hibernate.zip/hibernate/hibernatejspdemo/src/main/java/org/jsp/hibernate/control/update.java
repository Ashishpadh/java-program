package org.jsp.hibernate.control;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.jsp.hibernate.dto.User;

public class update {
	
	public static void main(String[] args) {
		
		User u=new User();
		u.setId(2);
		u.setName("ashhda");
		u.setPhone(234);
		u.setPassword("a23");
		u.setAge(24);
		u.setEmail("ashise22eh@gmail.com");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		EntityTransaction tra=em.getTransaction();
		em.merge(u);
		tra.begin();
		tra.commit();
		System.out.println("user saved id  :"+u.getId());
		
	
	}
}
