import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.jsp.hibernate.dto.User;

public class VeryfyUser {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the phone and password and display the deteles");
		long phone=sc.nextLong();
		String password=sc.next();
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager em=factory.createEntityManager();
		
		String hql="select u from User u where u.phone=?1 and u.password=?2"; 
		Query q=em.createQuery(hql);
		q.setParameter(1, phone);
		q.setParameter(2, password);
		try {
			User u=(User) q.getSingleResult();
			System.out.println("your details are verified");
			System.out.println("id :"+u.getId());
			System.out.println("name :"+u.getName());
			System.out.println("phone :"+u.getPhone());
			System.out.println("age :"+u.getAge());
		}
		catch(NoResultException e){
			e.printStackTrace();
			System.out.println("invalid phone number and password");
		}
		
	}

}
